#!/bin/bash

#This configures the path of the scripts folder. 
commands=$1
echo commands
foldar_name="scripts"
path_of_cellar="$prefix$foldar_name"

echo "path: $path_of_cellar"

#sed -i -e "s|scripts|$path_of_cellar|g" The_pipe.sh




