
#This configures the path of the scripts folder. 


foldar_name="scripts"
path_of_cellar="$prefix$foldar_name"
echo $path_of_cellar
sed -i -e "s|scripts|$path_of_cellar|g" The_pipe.sh




