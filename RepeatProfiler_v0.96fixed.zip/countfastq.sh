if gzip -t /mnt/d/Pipeline_project/scriptTest/reads/5M_isoG_1.fq.gz; then
    echo 'file is ok'
	

else 
	echo "a7a"
fi
