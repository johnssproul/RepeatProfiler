echo '								************************Repeat_Profiler***********************' > ReadMe.txt

echo "The tool uses numbers to refer to your read/read pairs for the ease of dealing with it , and in most cases it always converts them back to  your read names">> ReadMe.txt
echo "However, there are some output that cannont have your read names so we use the index instead like phylip file and the name of the subfolders of refrences output folders for simplicity">> ReadMe.txt
echo "so please use this table below to understand it. Sorry for any inconvenience">> ReadMe.txt
echo '		' >> ReadMe.txt

echo 'Index -> Reads:' >> ReadMe.txt
echo '		' >> ReadMe.txt
