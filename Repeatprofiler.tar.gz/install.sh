#!/bin/bash

#This configures the path of the scripts folder. 


intial_path=`echo   $(brew --prefix)/cellar/repeat-test/1.1 `
#foldar_name="scripts"
path_of_cellar="$intial_path$foldar_name"
echo $path_of_cellar


sed -i -e "s|scripts|$path_of_cellar|g" The_pipe.sh




