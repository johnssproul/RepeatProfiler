echo '								************************Repeat_Profiler***********************' > ReadMe.txt
echo '		' >> ReadMe.txt

echo 'Index -> Reads:' >> ReadMe.txt
echo '		' >> ReadMe.txt
